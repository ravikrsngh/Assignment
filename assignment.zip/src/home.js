import './App.css';
import scrollicon from './assets/scroll.png';
import React from "react";

import {useState, useEffect} from "react";
import { useQuery } from 'react-query';

import NewPara from './components/newpara/newpara';
import ItemCard from './components/itemcard/itemcard';


const HomePage = ({initialData}) => {

  let [oldItems,setOldItems] = useState([])

  let [isFetching,setIsFetching] = useState(false)

  const fetchData1 = async (start_date,end_date) => {
    setIsFetching(true)
    fetch('https://api.nasa.gov/planetary/apod?api_key=gaff4Pwpu0Qg6woyFty1YhVRxhj4In1ImvOCyFD7&start_date=2022-10-01&end_date=2022-10-29&thumbs=true').then((res) => {
      return res.json();
    }).then((data) => {
      data.reverse()
      setOldItems((prev)=> {
        return [...prev,...data]
      })
    })
  }

  const fetchData2 = async (start_date,end_date) => {
    const res = await fetch('https://api.nasa.gov/planetary/apod?api_key=gaff4Pwpu0Qg6woyFty1YhVRxhj4In1ImvOCyFD7&start_date=2022-10-01&end_date=2022-10-29&thumbs=true')
    return res.json()
  }

  const getPreviousItem = () => {

    let last7 = initialData.slice(initialData.length - 8,initialData.length-1).reverse()
    console.log(last7);
    let list = last7.map((ins) => <ItemCard key={ins.explanation} data={ins}/>)
    return list
  }

  const getOldItems = () => {
    let olditms = initialData.slice(0,initialData.length-8).reverse()
    setOldItems(olditms)
  }

  useEffect(()=>{
    getOldItems();
  },[])

  // useEffect(()=>{
  //   let fetching = false
  //   const onScroll = async (event) => {
  //     const { scrollHeight, scrollTop, clientHeight } =
  //       event.target.scrollingElement;
  //     if (!fetching && scrollHeight - scrollTop <= clientHeight * 1.5) {
  //       fetching=true
  //       fetch('https://api.nasa.gov/planetary/apod?api_key=gaff4Pwpu0Qg6woyFty1YhVRxhj4In1ImvOCyFD7&start_date=2022-10-01&end_date=2022-10-29&thumbs=true').then((res) => {
  //         return res.json();
  //       }).then((data) => {
  //         data.reverse()
  //         setOldItems((prev)=> {
  //           return [...prev,...data]
  //         })
  //         fetching = false
  //       })
  //     }
  //   };
  //
  //   document.addEventListener("scroll", onScroll);
  //   return () => {
  //     document.removeEventListener("scroll", onScroll);
  //   };
  // },[])

  return (
    <React.Fragment>
      <div className="spotlight_section">
        <div className="spotlight_1">
          <h2>{(initialData.at(-1)).title}</h2>
          <NewPara text={(initialData.at(-1)).explanation} />
          <div className="spotlight_scroll">
            <img src={scrollicon} />
            <p>
            Scroll Down
            <span>to discover more</span>
            </p>
          </div>
        </div>
        <div className="spotlight_2">
          {initialData.at(-1).media_type == 'image' && <img src={initialData.at(-1).url} />}
        </div>
      </div>

      <h3>Previous Items</h3>
      <div className="previous_items_container item_container">
        <div className="previous_items">
        {getPreviousItem()}
        </div>
      </div>

      <h3>Older Items</h3>
      <div className="old_items_container item_container">
        {oldItems.map((ins) => <ItemCard key={ins.explanation} data={ins}/>)}
      </div>

    </React.Fragment>
  )

}


export default HomePage;
