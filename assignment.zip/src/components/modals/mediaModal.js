import './modals.css';
import React from 'react';
import ReactDOM from 'react-dom';

const MediaModal = ({type,source}) =>{
  return (
    <React.Fragment>
    {ReactDOM.createPortal(
      (
        <div className='modal_container'>
        </div>
      ),
      document.getElementById('modals')
    )}
    </React.Fragment>
  )
}

export default MediaModal;
