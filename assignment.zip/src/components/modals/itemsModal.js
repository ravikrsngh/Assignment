import './modals.css';

const ItemsModal = ({opened, onClose}) => {
  const close = () => {
    console.log("hey");
    onClose();
  }

  if (!opened) return null;

  return (
    <div className='modal_container'>
      <h1 style={{
        width: '500px',
        height: '500px',
        background: 'coral'
      }} onClick={close}>Hey</h1>
    </div>
  )
}

export default ItemsModal;
