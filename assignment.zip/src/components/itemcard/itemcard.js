import './itemcard.css';
import {useState} from 'react';
import ItemsModal from './../modals/itemsModal.js';

const ItemCard = ({data}) => {

  const [showItemDetails,setShowItemDetails] = useState(false)

  return (
    <div className="item_card" onClick={() => setShowItemDetails(true)}>
      <div className="item_img_container" style={{backgroundImage: `url(${data.media_type == 'image'? data.url : data.thumbnail_url})`}}>

      </div>
      <div className="item_card_info">
        <h4>{data.title}</h4>
        <span>{data.date}</span>
      </div>
      <ItemsModal data={data} opened={showItemDetails} onClose={() => setShowItemDetails(false)}/>
    </div>
  )
}

export default ItemCard;
