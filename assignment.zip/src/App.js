import './App.css';
import Header from './components/header/header';
import HomePage from './home';

import {useState, useEffect} from 'react'
import { QueryClient, QueryClientProvider } from 'react-query'
import { useQuery } from 'react-query'

function App() {

  const [initialData, setInitialData] = useState([{copyright:"",date:"",hdurl:"",media_type:"",url:"",explanation:"",title:""}])
  const [isLoading, setIsLoading] = useState(true)



  const fetchInitialData = () => {
    let res = fetch('https://api.nasa.gov/planetary/apod?api_key=gaff4Pwpu0Qg6woyFty1YhVRxhj4In1ImvOCyFD7&start_date=2022-10-01&end_date=2022-10-29&thumbs=true').then((res) => {
      return res.json();
    }).then((data) => {
      setInitialData(data)
      setIsLoading(false)
    })
  }

  useEffect(() => {
    fetchInitialData()
  },[])

  if (isLoading) {
    return (
      <div className="App">
        <Header />
      </div>
    )
  }

  return (
    <div className="App">
      <Header />
      <HomePage initialData={initialData} />
    </div>
  );

}

export default App;
